# WYZ 的个人作品集

个人站点：作品展示 + 源码预览 + 实时留言板 + Minecraft 存档下载。

## 线上地址

https://wbapp-4yjji4lq7zfvvllenf3oul.app.workbuddy.host/?sharecode=PP3FHQM5NB

> 链接必须带 `sharecode`，否则会被服务器挡成 403。

## 目录结构

```
├── site/                    站点源码（可直接部署）
│   ├── index.html           首页：作品 / 存档 / 关于 / 联系
│   ├── guestbook.html       留言板（云数据库 + 轮询 + 回复）
│   ├── assets/              分享图、收款码、作品截图、存档图标
│   ├── sdk/                 云服务 SDK（本地化，不依赖 CDN）
│   ├── source-preview/      源码预览用的纯文本
│   └── downloads/           作品源码包（base64 文本）
├── build/                   构建与抓取脚本
│   ├── grab_xxez.py         抓取学校站源码
│   ├── pack.py              打包作品源码 + 生成预览文本
│   ├── pack_mc.py           打包 Minecraft 存档为 .mcworld
│   └── README.md            站点源码包的详细说明
└── .github/workflows/       GitHub Pages 自动部署
```

## 本地运行

不能双击 HTML，页面里有 `fetch()`，`file://` 下会被浏览器拦。

```bash
python -m http.server 8000 --directory site
# 打开 http://localhost:8000
```

留言板在 localhost 下连不上——云服务端会校验 Origin，只认线上域名。

## 部署到 GitHub Pages

仓库已带 `.github/workflows/pages.yml`。推到 `main` 之后：

1. 仓库 **Settings → Pages**
2. **Source** 选 `GitHub Actions`
3. 推一次代码，自动构建部署

**注意**：GitHub Pages 上只有静态部分可用。留言板依赖 WorkBuddy 云服务，服务端做严格 Origin 校验，换域名后会连不上。要用留言板得重新开通云服务并替换 `guestbook.html` 里的 `CLOUD_CONFIG`。

## Minecraft 存档

`site/downloads/mc/` 下 4 个 `.mcworld`（合计 108 MB）**不在仓库里**，因为超过 GitHub 的舒适区（单文件上限 100 MB）。

需要的话：
- 用 GitHub Release 上传附件（单个支持 2 GB），或
- 本地保留 `build/mc/` 直接拷贝

`.mcworld` 本质是 zip，Minecraft 双击即可导入。存档为 1.16.5 + Forge 36.2.42。

## 几个设计取舍

1. **SDK 放本地**：`jsdelivr` 在部分网络下完全打不开，页面会白屏。别改回 CDN。
2. **作品源码包用 base64 文本**：部署平台拦截 `.zip`（连文件名含 `.zip` 都不行），浏览器端取回后解码还原。
3. **留言板 3 秒轮询**：云服务只有数据库读写，没有推送通道。用 `id > lastId` 做增量。
4. **留言无删除入口**：数据库只开了 SELECT / INSERT 策略，改不了也删不掉别人的留言。

## 版权

页面代码自写。`assets/sponsor-qr.png` 是个人收款码，对外分发前建议删除，同时移除 `index.html` 里的赞助弹层。
