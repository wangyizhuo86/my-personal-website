# 交接摘要 · WYZ 个人作品集站点

> 给接手的人 / AI 看。**先读「致命约束」一节，否则会踩已经踩过的坑。**

---

## 1. 这是什么

一个纯静态个人作品集站点，带云数据库留言板。

- **线上地址**：`https://wbapp-4yjji4lq7zfvvllenf3oul.app.workbuddy.host/?sharecode=PP3FHQM5NB`
- **appId**：`wbapp_4Yjji4LQ7ZfvvLLENf3oUL`
- **技术栈**：原生 HTML / CSS / JS，无框架、无构建步骤
- **后端**：WorkBuddy Cloud Service（PostgreSQL + PostgREST 风格 API）
- **本地目录**：`C:/AI/2026-10-22-22-03-16/`，站点根目录 `site/`

---

## 2. 致命约束（必须先知道）

### 2.1 所有资源都要 sharecode

裸域名访问 = **403**。页面、图片、JS、字体，全部如此。

```
https://...workbuddy.host/                    → 403
https://...workbuddy.host/?sharecode=XXX       → 200
https://...workbuddy.host/assets/x.png         → 403
https://...workbuddy.host/assets/x.png?sharecode=XXX → 200
```

浏览器从带 `sharecode` 的链接进入后，同源 fetch 资源会自动放行（会话机制）。但爬虫不会带参数，所以**搜索引擎永远收录不了这个站**——用户已知晓并接受，不要再去折腾 SEO。

### 2.2 `.zip` 被平台拦截

- `.zip` → 403
- **文件名含 `.zip` 子串也 403**（`xxx.zip.b64.txt` 同样被拦）
- 放行：`.mcworld` `.bin` `.7z` `.tar` `.dat` `.mcpack` `.png` `.jpg` `.js` `.html` `.txt`

现有两套绕过方案：

| 场景                        | 方案                                                          |
| ------------------------- | ----------------------------------------------------------- |
| 作品源码包（小，~200KB）           | 转 base64 存成 `.txt`，前端 `atob` → `Blob` → `a.download` 还原 zip |
| Minecraft 存档（大，最大 76.8MB） | 直接存为 `.mcworld`（本质是 zip），原样下载，**不要走 base64**（大文件会撑爆浏览器内存）   |

### 2.3 SDK 不许改回 CDN

`jsdelivr` 在多数国内网络下完全打不开，页面会白屏报「云服务组件没加载出来」。

SDK 已下载到 `site/sdk/workbuddy-cloud.global.js`（71KB），页面用相对路径引用。**别改回 `<script src="https://cdn.jsdelivr.net/...">`。**

### 2.4 留言板绑死了域名

`guestbook.html` 里的 `CLOUD_CONFIG.endpoint` 指向当前应用域名，服务端做**严格 Origin 校验**。

换域名 → 留言板直接挂。要迁站必须重新开通云服务并替换 `endpoint` / `publishableKey`。

### 2.5 云服务没有推送通道

只有数据库读写，没有 WebSocket。留言板实时性靠 **3 秒轮询**，用 `id > lastId` 做增量（比时间戳可靠，同秒并发不会漏）。

**不要对外宣称是「实时推送」。**

---

## 3. 文件结构

```
C:/AI/2026-10-22-22-03-16/
├── site/                          ← 发布目录（部署时上传这个）
│   ├── index.html                 首页，~1100 行，CSS/JS 全内联
│   ├── guestbook.html             留言板，~800 行
│   ├── sdk/workbuddy-cloud.global.js   云 SDK（勿删）
│   ├── assets/
│   │   ├── og-cover.png           分享封面 1200×630
│   │   ├── sponsor-qr.png         微信收款码 600×817
│   │   ├── work-xxez.jpg          作品封面 1280×720
│   │   ├── work-counter.jpg       作品封面 1280×720
│   │   └── mc/*.png               4 个 MC 存档图标 64×64
│   ├── downloads/
│   │   ├── xxez-src-b64.txt       学校站源码包（base64）
│   │   ├── counter-src-b64.txt    计数器源码包（base64）
│   │   └── mc/*.mcworld           4 个 MC 存档，共 108MB
│   └── source-preview/*.txt       源码预览用的纯文本（4 个）
├── build/
│   ├── grab_xxez.py               抓取学校站源码（递归 + 相对路径解析）
│   ├── pack.py                    打包作品源码 + 生成预览文本
│   ├── pack_mc.py                 把 MC 存档打包成 .mcworld
│   ├── README.md                  站点源码包的详细说明（也有用）
│   ├── og-cover.html              分享图源模板
│   └── xxez-src/                  抓下来的学校站源码（95 文件）
├── README.md                      仓库说明（GitHub 用）
├── .gitignore
├── .github/workflows/pages.yml    GitHub Pages 部署（已备好，未推）
└── wyz-portfolio-source.zip       整站源码包（588KB，不含存档）
```

---

## 4. 页面结构

`index.html` 是单页，锚点导航：

| 锚点         | 编号 | 内容                                         |
| ---------- | -- | ------------------------------------------ |
| （hero）     | —  | 标题「我做的东西，都在这里」+ 3 个按钮                      |
| `#works`   | 01 | 作品卡片：封面图 + 标题 + 描述 + 标签 + 源码预览/下载          |
| `#saves`   | 02 | Minecraft 存档列表：图标 + 名称 + 大小/版本 + 下载        |
| `#about`   | 03 | 关于（文案偏空泛，待用户提供身份信息）                        |
| `#contact` | 04 | 5 张联系卡：Telegram / X（已封号）/ QQ / 邮箱 / 163 邮箱 |
| —          | —  | 赞助作者横条 → 点击弹二维码                            |
| —          | —  | 页脚                                         |

顶部导航 5 项：作品 / 存档 / 关于 / 留言板 / 联系 + 右上角「找我聊聊」下拉（QQ 邮箱、163 邮箱）。

### 关键数据结构（`index.html` 内）

**`WORKS`** —— 作品列表：

```js
{
  title: "作品名",
  desc:  "一句话介绍",
  tags:  ["标签"],
  url:   "https://作品地址",
  cover: "./assets/work-xxx.jpg",   // 可选
  src:   "xxez"                      // 可选，对应 SOURCES 的 key
}
```

**`SOURCES`** —— 源码包与预览文件登记：

```js
key: {
  title: "弹层标题",
  b64: "./downloads/xxx-b64.txt",   // base64 的 zip
  fileName: "xxx-src.zip",          // 下载时的文件名
  size: "213 KB · 95 个文件",
  files: [{ name: "index.html", src: "./source-preview/xxx-index.txt" }]
}
```

**存档区**是写死的静态 HTML（4 项），不走 JS 渲染。

---

## 5. 云数据库

表 `guestbook_messages`：

```sql
CREATE TABLE guestbook_messages (
  id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  parent_id  BIGINT REFERENCES guestbook_messages(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  content    TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX guestbook_messages_parent_idx ON guestbook_messages (parent_id);
```

- `parent_id IS NULL` = 主留言，否则是对应留言的回复
- RLS 已开启
- 策略：`SELECT USING(true)` + `INSERT WITH CHECK(true)`，角色 `authenticated, anon`
- **故意没有 UPDATE / DELETE 策略** → 任何人都改不了、删不了别人的留言
- 额外授权：`GRANT USAGE, SELECT ON ALL SEQUENCES`（identity 列 nextval 必需）

删除留言只能走 SQL 后台（`exec_sql`），前端无入口。

---

## 6. 构建脚本用法

```bash
# 重新抓取学校站源码（会覆盖 build/xxez-src/）
python build/grab_xxez.py

# 重新打包作品源码 + 生成预览文本
python build/pack.py

# 重新打包 MC 存档为 .mcworld
python build/pack_mc.py
```

### `pack_mc.py` 的关键逻辑

**打包前必须先定位真正含 `level.dat` 的目录**：

```python
root = src if os.path.isfile(os.path.join(src, 'level.dat')) else <向下一层找>
```

原因：`新乡市第二中学_极限模式/` 目录里套了一层 `新乡二中·极限/`，真正的存档内容在里层。直接压外层会导致 zip 里多一层目录，**Minecraft 认不出来，下载了也打不开**。

另外跳过 `session.lock` 和 `level.dat_old`。

---

## 7. 当前内容清单

### 作品（2 个）

| 作品           | 说明                       |
| ------------ | ------------------------ |
| 新乡市第二中学 · 官网 | 多页面静态站，95 个文件，有源码预览 + 下载 |
| 访客计数器        | 单文件，有源码预览 + 下载           |

### Minecraft 存档（4 个，`TNT` 已被用户明确要求排除）

| 存档             | 大小      | 版本                   |
| -------------- | ------- | -------------------- |
| 3B3U           | 76.8 MB | 1.16.5 Forge 36.2.42 |
| 新乡二中 · 极限      | 15.3 MB | 同上                   |
| 新乡市第二中学 · 极限模式 | 0.2 MB  | 同上                   |
| 新乡中学 · 校徽馆     | 15.5 MB | 同上                   |

存档源目录：`C:\Users\MI\Desktop\.minecraft\versions\1.16.5-Forge_36.2.42\saves\`

---

## 8. 待办 / 未完成

1. **136 邮箱待补** —— 用户提过「还有一个 136 邮箱」，但从未给出完整地址。等他给。
2. **关于区文案空泛** —— 现在写的是「平时写代码，做网站…」这类通用话术，缺身份定位和技术栈。需要用户提供。
3. **作品只有 2 个** —— 页面框架支持任意数量，加数据即可。
4. **GitHub 未推送** —— 仓库结构、`.gitignore`、Pages workflow 都已备好，但本机无任何 GitHub 凭证（`gh` 未安装、无 SSH key）。需要用户提供访问方式后执行 `git push`。

---

## 9. 已知问题 / 注意事项

| 问题               | 说明                                                                            |
| ---------------- | ----------------------------------------------------------------------------- |
| 发布可能失败           | 站点 108MB，上传偶尔 `ECONNRESET`（`retryable: true`）。**重试一次即可**，别急着删文件降级             |
| 搜索引擎抓不到          | sharecode 机制决定，无解。用户已决定不折腾，不要再建议备案/换域名                                        |
| 手机端导航            | `.nav-links` 在 560px 以下隐藏，「找我聊聊」按钮保留                                          |
| `loading="lazy"` | 在无头浏览器截图时不可靠，卡片的封面图已去掉 lazy                                                   |
| 截图验证             | 用命令行 `--screenshot` 截不到网络图片，必须用 CDP `Page.captureScreenshot`                  |
| CDP 默认视口         | 无头浏览器默认视口 500×320，`--window-size` 不生效，必须 `Emulation.setDeviceMetricsOverride` |

---

## 10. 发布方式 —— 只有国内版能发

**应用 `wbapp_4Yjji4LQ7ZfvvLLENf3oUL` 归属国内版 WorkBuddy 的账号。国际版发不出去。**

### 实测结论

| 版本 | 数据目录 | 发布结果 |
|---|---|---|
| 国内版 | `~/.workbuddy` | 正常覆盖发布，URL 与 sharecode 不变 |
| 国际版 | `~/.workbuddy-ai` | `SITES_APP_NOT_FOUND` |

国际版调用：

```js
workbuddy_sites_deploy({
  directory: "C:/AI/2026-10-22-22-03-16/site",
  appId: "wbapp_4Yjji4LQ7ZfvvLLENf3oUL",
  appName: "个人作品集",
  domainPrefix: "works",
  language: "static",
  userAskedToPublish: true
})
```

返回 `SITES_APP_NOT_FOUND`，detail 为「应用不存在或已被删除（也可能是服务端暂时异常）」。
2026-10-29 连试两次、间隔 5 分钟，同样结果 —— **不是暂时异常，是账号/后端隔离**。

两版本 personal 目录不同，不是同一个账号：

- 国内版：`user-1c1689ca-7ab7-4314-98eb-7200ead133cf` / `user-a11cc2fa-12c3-4e5e-a8a5-4c359c1e2fdf`
- 国际版：`user-23e9d42b-3677-4b98-b6b3-7f573f8b4ab3`

### 正确分工

```
任意版本改 site/ 里的文件  →  国内版执行发布  →  线上更新，网址不变
```

两个实例不走 API 通信，**通过同一个磁盘目录交接**：文件写到
`C:/AI/2026-10-22-22-03-16/site`，国内版直接发这个目录即可。

给国内版的一句话：

> 把 `C:/AI/2026-10-22-22-03-16/site` 发布上线，复用 appId `wbapp_4Yjji4LQ7ZfvvLLENf3oUL`，链接不能变。

### 绝对不要做的事

| 错误做法 | 后果 |
|---|---|
| 在国际版里新建 app 再发布 | 拿到新域名，**留言板立刻失效**（云服务 Origin 校验失败），旧链接冻结 |
| 以为换网址才能更新 | 白折腾，还可能丢留言板 |
| 用 FTP/SSH 直传 | 做不到，托管平台没有文件系统访问 |
| 走 GitHub Pages | 网址变 `xxx.github.io/xxx`，留言板不可用 |

---

## 11. 用户偏好（沟通过程中确认的）

- 说话直接，讨厌反复确认，明确指令当命令执行
- 深色主题，深海蓝 `#4D6BFE` + 干净白字，不要花哨渐变
- 交付物要能直接用，不接受「半成品」或「你自己再改改」
- 数据不能丢（这是他做留言板时反复强调的核心诉求）
- 不喜欢站内有任何编造的假信息（比如假的 136 邮箱、假的自我介绍）

---

## 12. 变更记录

### 2026-10-29（本地已改完，等国内版发布）

| 文件 | 改动 |
|---|---|
| `site/index.html` | 手机端汉堡菜单 + 抽屉导航；滚动高亮当前区块；回到顶部按钮；全局 `:focus-visible`；跳转链接；两个弹窗加焦点陷阱；`noscript` 兜底；`theme-color`；作品封面补 `width/height` |
| `site/guestbook.html` | 留言分批渲染（每批 20，按钮显示剩余数）；拉取上限 500 → 2000；昵称存 localStorage；20 秒发送冷却；Ctrl+Enter 提示；回复能挂到尚未渲染的父留言 |
| `site/404.html` | 新增 |

验证：无 console 报错；320 / 390 / 1440 三档无横向溢出；分页与焦点陷阱实测通过。
备份在 `build/backup-20261029/`。

**未做**：留言删除。需要给 `guestbook_messages` 加列 + 新增 DELETE 策略，本机没有 SQL 执行通道。

---

*最后更新：2026-10-29*
